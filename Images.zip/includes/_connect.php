<?php
$db_server = "plesk.remote.ac";
$db_user = "ws350074_csd";
$db_password = "L354&t7ujr72s9t~U1";
$db_database = "ws350074_csd";
$db_connect = mysqli_connect($db_server,$db_user,$db_password,$db_database);

if (!$db_connect) {
    echo "Error: Unable to connect!";
}
